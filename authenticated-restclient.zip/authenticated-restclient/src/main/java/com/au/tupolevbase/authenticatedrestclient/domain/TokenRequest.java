package com.au.tupolevbase.authenticatedrestclient.domain;

public class TokenRequest {

    private String appId;
    private String secret;

    public TokenRequest() {
    }

    public TokenRequest(String appId, String secret) {
        this.appId = appId;
        this.secret = secret;
    }

    public String getAppId() {
        return appId;
    }

    public String getSecret() {
        return secret;
    }
}
