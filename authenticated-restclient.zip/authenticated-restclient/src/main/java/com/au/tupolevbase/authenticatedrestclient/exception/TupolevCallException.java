package com.au.tupolevbase.authenticatedrestclient.exception;


public class TupolevCallException extends Exception {

    public TupolevCallException(String message) {
        super(message);
    }
}
