package com.au.tupolevbase.authenticatedrestclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Configuration;

@SpringBootApplication
@EnableCaching
public class AuthenticatedRestClientApplication {

	@Bean
	public Client createClient() {
		Client client = ClientBuilder.newClient();
		return client;
	}

	public static void main(String[] args) {
		SpringApplication.run(AuthenticatedRestClientApplication.class, args);
	}

}
