package com.au.tupolevbase.authenticatedrestclient.exception;


public class AuthenticateException extends Exception {

    public AuthenticateException(String message) {
        super(message);
    }
}
