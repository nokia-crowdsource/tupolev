# Authenticated Rest Client (Library)

### Purpose
This is a shiny new wrapper library over the Glassfish Jersey (2.12) to make implicit token based (cached/refreshed) REST Calls. 
Below are the major Jersey libraries that are used in this.

* [jersey-client]()
* [jersey-media]()
* [jersey-common]()


### Advantages
This wrapper library of Glassfish Jersey has below major advantages for developers

* Removes lot of boiler plate code in making the REST call.
* Highly configurable token end points (You can go whatever token provider/url)
* Polymorphic and REST method agnostic coding.

### Building and Compiling

    ./gradlew clean build
    
### Usage
Use it with any Springboot project with very minimal configuration changes. 

    @Import(AuthenticatedRestClientApplication.class) => Goes in the main Application in Springboot

This plugs the authenticated rest client component to your base Springboot Application and also makes it configurable.


    ---
    .....
    .....
    restclient:
        authUrl: 'any token api'
        appId: 'application id'
        secret: 'application specific secret'
        
The above configuration needs to be added to the application.yml
